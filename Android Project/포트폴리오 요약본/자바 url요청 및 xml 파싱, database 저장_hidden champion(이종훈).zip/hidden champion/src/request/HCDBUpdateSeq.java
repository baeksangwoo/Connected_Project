package request;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class HCDBUpdateSeq {

	public int idxStart;
	public int idxSize;
	public int totalSize;
	public String[] response;
	ArrayList<CompanyDAO> companyDao;
	ArrayList<ComseqDAO> comseqDao;

	HCDBUpdateSeq(int idxStart, int idxSize) {
		this.idxStart = idxStart;
		this.idxSize = idxSize;
		totalSize = 0;
		companyDao = new ArrayList<>();
		comseqDao = new ArrayList<>();
	}

	public void updateDB() throws Exception {
		getDB();
		requestAPI1();
		parsingApiData();
		setDB();

		showResult();
	}

	public void getDB() {

		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			String sql = "SELECT com_id, com_brnum, com_name, com_addg, com_addggu, com_addgguemd FROM Company WHERE com_id BETWEEN ? AND ?";

			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hcdb", "hcdb");
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, idxStart);
			pstmt.setInt(2, idxStart + idxSize);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				totalSize++;
				companyDao.add(new CompanyDAO(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getInt(5),
						rs.getInt(6)));
			}

			pstmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void requestAPI1() throws Exception {

		response = new String[totalSize];

		for (int i = 0; i < totalSize; i++) {
			System.out.println(i);
			StringBuilder urlBuilder = new StringBuilder(
					"http://apis.data.go.kr/B552015/NpsBplcInfoInqireService/getBassInfoSearch");
			urlBuilder.append("?" + URLEncoder.encode("ServiceKey", "UTF-8")
					+ "=fntF2875bK1vH0uhenZ5rExmG8r8MCuStfZBb2ePzS1yl2vRH5cIsS5eF67XC%2F4A1CD3KGrvnp4bG2SicB9fcA%3D%3D");
			urlBuilder.append("&" + URLEncoder.encode("ldong_addr_mgpl_dg_cd", "UTF-8") + "="
					+ URLEncoder.encode(Integer.toString(companyDao.get(i).com_addg), "UTF-8"));
			urlBuilder.append("&" + URLEncoder.encode("ldong_addr_mgpl_sggu_cd", "UTF-8") + "="
					+ URLEncoder.encode(Integer.toString(companyDao.get(i).com_addggu), "UTF-8"));
			urlBuilder.append("&" + URLEncoder.encode("ldong_addr_mgpl_sggu_emd_cd", "UTF-8") + "="
					+ URLEncoder.encode(Integer.toString(companyDao.get(i).com_addgguemd), "UTF-8"));
			urlBuilder.append("&" + URLEncoder.encode("wkpl_nm", "UTF-8") + "="
					+ URLEncoder.encode(companyDao.get(i).com_name, "UTF-8"));
			urlBuilder.append("&" + URLEncoder.encode("bzowr_rgst_no", "UTF-8") + "="
					+ URLEncoder.encode(Integer.toString(companyDao.get(i).com_brnum), "UTF-8"));
			urlBuilder.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8"));
			urlBuilder.append("&" + URLEncoder.encode("startPage", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8"));
			urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "=" + URLEncoder.encode("28", "UTF-8"));
			urlBuilder.append("&" + URLEncoder.encode("pageSize", "UTF-8") + "=" + URLEncoder.encode("28", "UTF-8"));

			URL url = new URL(urlBuilder.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/json");
			BufferedReader rd;
			if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
				rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			} else {
				rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			}
			String line;

			while ((line = rd.readLine()) != null) {
				response[i] = line + "id" + Integer.toString(companyDao.get(i).com_id) + "<";
			}
			rd.close();
			conn.disconnect();
		}
	}

	public void parsingApiData() {

		YMS[] yms = new YMS[4];
		yms[0] = new YMS(2015);
		yms[1] = new YMS(2016);
		yms[2] = new YMS(2017);
		yms[3] = new YMS(2018);

		for (int i = 0; i < totalSize; i++) {
			String tmp = "";
			int idx;
			int id;
			int totalCnt = 0;

			idx = response[i].indexOf("totalCount") + 11;
			while (true) {
				if (response[i].charAt(idx) == '<')
					break;
				tmp += response[i].charAt(idx++);
			}
			totalCnt = Integer.parseInt(tmp);

			idx = response[i].indexOf("id") + 2;
			tmp = "";
			while (true) {
				if (response[i].charAt(idx) == '<')
					break;
				tmp += response[i].charAt(idx++);
			}
			id = Integer.parseInt(tmp);

			while (totalCnt-- > 0) {
				tmp = "";
				idx = response[i].indexOf("dataCrtYm") + 10;
				String ym = response[i].substring(idx, idx + 6);
				int y = Integer.parseInt(ym.substring(0, 4));
				int m = Integer.parseInt(ym.substring(4));
				idx = response[i].indexOf("seq") + 4;
				while (true) {
					if (response[i].charAt(idx) == '<')
						break;
					tmp += response[i].charAt(idx++);
				}
				int sq = Integer.parseInt(tmp);
				for (int k = 0; k < 4; k++) {
					if (yms[k].year == y) {
						yms[k].ms[m - 1] = sq;
						yms[k].cnt++;
					}
				}
				response[i] = response[i].substring(idx + 6);
			}
			for (int j = 0; j < 4; j++) {
				if (yms[j].cnt == 0)
					continue;
				comseqDao.add(new ComseqDAO(id, yms[j].year, yms[j].ms));
			}
		}
	}

	public void setDB() {

		try {
			Connection conn = null;
			PreparedStatement pstmt = null;

			String sql = "INSERT INTO Comseq VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hcdb", "hcdb");
			pstmt = conn.prepareStatement(sql);

			for (int i = 0; i < comseqDao.size(); i++) {
				pstmt.setInt(1, comseqDao.get(i).com_id);
				pstmt.setInt(2, comseqDao.get(i).seq_year);
				for(int j=0;j<12;j++)
					pstmt.setInt(j+3, comseqDao.get(i).seq[j]);
				
				pstmt.executeUpdate();
			}
			pstmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void showResult() {

		for (int i = 0; i < companyDao.size(); i++) {
			System.out.println("com_id : " + companyDao.get(i).com_id);
			System.out.println("com_brnum : " + companyDao.get(i).com_brnum);
			System.out.println("com_name : " + companyDao.get(i).com_name);
			System.out.println("com_addg : " + companyDao.get(i).com_addg);
			System.out.println("com_addggu : " + companyDao.get(i).com_addggu);
			System.out.println("com_addgguemd : " + companyDao.get(i).com_addgguemd);
			System.out.println();
		}

		for (int i = 0; i < comseqDao.size(); i++) {
			System.out.println(comseqDao.get(i).com_id);
			System.out.println(comseqDao.get(i).seq_year);
			for(int j=0;j<12;j++)
				System.out.println(comseqDao.get(i).seq[j]);
		}
	}
}

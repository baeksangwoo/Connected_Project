package request;

public class ComseqDAO {

	int com_id;
	int seq_year;
	int[] seq;
	
	public ComseqDAO(int com_id, int seq_year, int[] seq) {
		super();
		this.com_id = com_id;
		this.seq_year = seq_year;
		this.seq = seq;
	}
}

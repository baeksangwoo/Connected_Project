package request;

public class CominDAO {

	int com_id;
	int in_year;
	int[] in;

	public CominDAO(int com_id, int in_year, int[] in) {
		super();
		this.com_id = com_id;
		this.in_year = in_year;
		this.in = in;
	}

}

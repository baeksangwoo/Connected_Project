package com.example.student.kreditjjob;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ListViewItemsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view_items);
    }
}

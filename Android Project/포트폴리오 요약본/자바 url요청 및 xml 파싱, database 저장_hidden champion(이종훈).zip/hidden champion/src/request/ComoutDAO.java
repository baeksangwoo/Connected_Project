package request;

public class ComoutDAO {

	int com_id;
	int out_year;
	int[] out;

	public ComoutDAO(int com_id, int out_year, int[] out) {
		super();
		this.com_id = com_id;
		this.out_year = out_year;
		this.out = out;
	}

}

package com.example.student.kreditjjob;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.SearchView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ListViewAdapter extends BaseAdapter {

    Context mContext;
    LayoutInflater inflater;
    private List<Company> companyList = null;
    private ArrayList<Company> arrayList;

    public ListViewAdapter(Context context, List<Company> companyList){
        mContext = context;
        this.companyList = companyList;
        inflater = LayoutInflater.from(mContext);
        this.arrayList = new ArrayList<Company>();
        this.arrayList.addAll(companyList);
    }

    public class ViewHolder{
        TextView name;
    }

    @Override
    public int getCount() {
        return companyList.size();
    }

    @Override
    public Object getItem(int position) {
        return companyList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {
        final ViewHolder holder;
        if(view == null){
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.list_view_items, null);
            holder.name = (TextView)view.findViewById(R.id.name);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }
        holder.name.setText(companyList.get(position).getCompany());

        // Listen for ListView Item Click
        view.setOnClickListener(new View.OnClickListener() {

          //  Bundle bundle  = new Bundle(1);


            Company item = (Company) getItem(position);
            String company = item.getCompany();

            @Override
            public void onClick(View v) {

                Intent intent = new Intent(mContext, ResultActivity.class);
                intent.putExtra("company", company);
                mContext.startActivity(intent);
            }
        });

        return view;
    }

    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        companyList.clear();
        if (charText.length() == 0) {
            companyList.addAll(arrayList);
        } else {
            for (Company c : arrayList) {
                if (c.getCompany().toLowerCase(Locale.getDefault()).contains(charText)) {
                    companyList.add(c);
                }
            }
        }
        notifyDataSetChanged();
    }
}

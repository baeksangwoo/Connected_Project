package com.example.student.kreditjjob;

import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class ResultActivity extends AppCompatActivity {

    public static String dirPath = Environment.getExternalStorageDirectory().getAbsoluteFile() + "/Android/com.four.hiddenchampion/temp";
    public static String fileName = "history.txt";

    WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Intent intent = getIntent();

        String quary = intent.getStringExtra("company");
        writeTextFile(quary);
        webView = findViewById(R.id.webView);
        webView.loadUrl("http://qortkdn123.dothome.co.kr/?company=" + quary);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);
    }

    public void writeTextFile(String contents){
        try{
            FileOutputStream fos = new FileOutputStream(dirPath+"/"+fileName, true);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
            bw.write(contents);
            bw.write("\n");
            bw.flush();

            bw.close();
            fos.close();
        }catch (Exception e){
            Log.v("writeTextFile ERROR", e.toString());
        }

    }
}

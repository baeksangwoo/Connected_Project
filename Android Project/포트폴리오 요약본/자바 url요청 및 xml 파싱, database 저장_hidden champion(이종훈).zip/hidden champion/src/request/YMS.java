package request;

public class YMS {
	int year;
	int[] ms;
	int cnt;

	YMS(int year) {
		this.year = year;
		ms = new int[12];
		cnt = 0;
	}
}
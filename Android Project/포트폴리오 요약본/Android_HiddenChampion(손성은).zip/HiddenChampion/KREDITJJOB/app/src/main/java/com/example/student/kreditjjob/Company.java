package com.example.student.kreditjjob;

public class Company {
    private String company;

    public Company(){}

    public Company(String company){
        this.company = company;
    }

    public String getCompany() {
        return this.company;
    }
}

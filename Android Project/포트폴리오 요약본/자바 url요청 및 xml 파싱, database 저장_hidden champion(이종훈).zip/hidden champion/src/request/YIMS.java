package request;

public class YIMS {

	int id;
	int year;
	int month;
	int in;
	int out;
	int[] inArr;
	int[] outArr;

	public YIMS(int id, int year, int month, int in, int out) {
		super();
		this.id = id;
		this.year = year;
		this.month = month;
		this.in = in;
		this.out = out;
	}

	public YIMS(int id, int year, int[] inArr, int[] outArr) {
		super();
		this.id = id;
		this.year = year;
		this.inArr = inArr;
		this.outArr = outArr;
	}
}

package request;

import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.io.BufferedReader;

public class HCDBInit {

	public int idxStart;
	public int idxSize;
	public int totalSize;
	public String[] response;
	public ArrayList<CompanyDAO> companyDao;

	HCDBInit(int idxStart, int idxSize){
		this.idxStart = idxStart;
		this.idxSize = idxSize;
		totalSize = 0;
		response = new String[idxSize];
		companyDao = new ArrayList<>();
	}
	
	public void initDB() throws Exception {
		requestAPI2();
		parsingApiData();
		setDB();
		showResult();
	}

	public void requestAPI2() throws Exception {

		for (int i = idxStart; i < idxStart + idxSize; i++) {
			System.out.println(i);
			StringBuilder urlBuilder = new StringBuilder(
					"http://apis.data.go.kr/B552015/NpsBplcInfoInqireService/getDetailInfoSearch");
			urlBuilder.append("?" + URLEncoder.encode("ServiceKey", "UTF-8")
					+ "=fntF2875bK1vH0uhenZ5rExmG8r8MCuStfZBb2ePzS1yl2vRH5cIsS5eF67XC%2F4A1CD3KGrvnp4bG2SicB9fcA%3D%3D");
			urlBuilder.append(
					"&" + URLEncoder.encode("seq", "UTF-8") + "=" + URLEncoder.encode(Integer.toString(i), "UTF-8"));

			URL url = new URL(urlBuilder.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/json");
			// System.out.println("Response code: " + conn.getResponseCode());
			BufferedReader rd;
			if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
				rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			} else {
				rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			}
			String line;

			while ((line = rd.readLine()) != null) {
				if (line.length() < 200)
					continue;
				response[totalSize++] = line + "id" + Integer.toString(i) + "<";
			}
			rd.close();
			conn.disconnect();
		}
	}

	public void parsingApiData() {

		int id;
		int bzowrRgstNo;
		String wkplNm;
		int wkplIntpCd;
		String vldtVlKrnNm;
		int jnngpCnt;
		int crrmmNtcAmt;
		String wkplRoadNmDtlAddr;
		int ldongAddrMgplDgCd;
		int ldongAddrMgplSgguCd;
		int ldongAddrMgplSgguEmdCd;

		String tmp = "";
		int j;
		for (int i = 0; i < totalSize; i++) {

			tmp = "";
			j = response[i].indexOf("id") + 2;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			id = Integer.parseInt(tmp);
			tmp = "";
			j = response[i].indexOf("bzowrRgstNo") + 12;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			bzowrRgstNo = Integer.parseInt(tmp.substring(0, 6));
			tmp = "";
			j = response[i].indexOf("wkplNm") + 7;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			wkplNm = tmp;
			tmp = "";
			j = response[i].indexOf("wkplIntpCd") + 11;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			wkplIntpCd = Integer.parseInt(tmp);
			tmp = "";
			j = response[i].indexOf("vldtVlKrnNm") + 12;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			vldtVlKrnNm = tmp;
			tmp = "";
			j = response[i].indexOf("jnngpCnt") + 9;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			jnngpCnt = Integer.parseInt(tmp);
			tmp = "";
			j = response[i].indexOf("crrmmNtcAmt") + 12;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			crrmmNtcAmt = Integer.parseInt(tmp);
			tmp = "";
			j = response[i].indexOf("wkplRoadNmDtlAddr") + 18;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			wkplRoadNmDtlAddr = tmp;
			tmp = "";
			j = response[i].indexOf("ldongAddrMgplDgCd") + 18;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			ldongAddrMgplDgCd = Integer.parseInt(tmp);
			;

			tmp = "";
			j = response[i].indexOf("ldongAddrMgplSgguCd") + 20;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			ldongAddrMgplSgguCd = Integer.parseInt(tmp);
			;

			tmp = "";
			j = response[i].indexOf("ldongAddrMgplSgguEmdCd") + 23;
			while (true) {
				if (response[i].charAt(j) == '<')
					break;
				tmp += response[i].charAt(j++);
			}
			ldongAddrMgplSgguEmdCd = Integer.parseInt(tmp);
			;

			if(wkplIntpCd == 999999) continue;
			companyDao.add(new CompanyDAO(id, bzowrRgstNo, wkplNm, wkplIntpCd, vldtVlKrnNm, jnngpCnt, crrmmNtcAmt,
					wkplRoadNmDtlAddr, ldongAddrMgplDgCd, ldongAddrMgplSgguCd, ldongAddrMgplSgguEmdCd));
		}
	}

	public void setDB() {
		
		try {
			Connection conn = null;
			PreparedStatement pstmt = null;

			String sql = "INSERT INTO Company VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hcdb", "hcdb");
			pstmt = conn.prepareStatement(sql);

			for (int i = 0; i < companyDao.size(); i++) {
				pstmt.setInt(1, companyDao.get(i).com_id);
				pstmt.setInt(2, companyDao.get(i).com_brnum);
				pstmt.setString(3, companyDao.get(i).com_name);
				pstmt.setInt(4, companyDao.get(i).com_tynum);
				pstmt.setString(5, companyDao.get(i).com_tynm);
				pstmt.setInt(6, companyDao.get(i).com_emps);
				pstmt.setInt(7, companyDao.get(i).com_amt);
				pstmt.setString(8, companyDao.get(i).com_addr);
				pstmt.setInt(9, companyDao.get(i).com_addg);
				pstmt.setInt(10, companyDao.get(i).com_addggu);
				pstmt.setInt(11, companyDao.get(i).com_addgguemd);

				pstmt.executeUpdate();
			}
			pstmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void showResult() {
		for (int i = 0; i < companyDao.size(); i++) {
			System.out.println("com_id : " + companyDao.get(i).com_id);
			System.out.println("com_brnum : " + companyDao.get(i).com_brnum);
			System.out.println("com_name : " + companyDao.get(i).com_name);
			System.out.println("com_tynum : " + companyDao.get(i).com_tynum);
			System.out.println("com_tynm : " + companyDao.get(i).com_tynm);
			System.out.println("com_emps : " + companyDao.get(i).com_emps);
			System.out.println("com_amt : " + companyDao.get(i).com_amt);
			System.out.println("com_addr : " + companyDao.get(i).com_addr);
			System.out.println("com_addg : " + companyDao.get(i).com_addg);
			System.out.println("com_addggu : " + companyDao.get(i).com_addggu);
			System.out.println("com_addgguemd : " + companyDao.get(i).com_addgguemd);
			System.out.println();
		}
	}
}

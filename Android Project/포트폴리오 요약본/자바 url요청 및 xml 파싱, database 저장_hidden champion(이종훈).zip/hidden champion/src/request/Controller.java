package request;

public class Controller {

	public static void main(String[] args) {

		for (int i = 12000; i < 15000; i += 100) {
			HCDBInit hcdbInit = new HCDBInit(i, 100);
//			HCDBUpdateSeq hcdbUpdateSeq = new HCDBUpdateSeq(i, 100);
//			HCDBUpdateInOut hcdbUpdateInOut = new HCDBUpdateInOut(i, 100);
			try {
				hcdbInit.initDB();
//				hcdbUpdateSeq.updateDB();
//				hcdbUpdateInOut.updateDB();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

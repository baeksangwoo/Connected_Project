package request;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class HCDBUpdateInOut {

	public int idxStart;
	public int idxSize;
	public int totalSize;
	public String[] response;
	ArrayList<ComseqDAO> comseqDao;
	ArrayList<CominDAO> cominDao;
	ArrayList<ComoutDAO> comoutDao;

	HCDBUpdateInOut(int idxStart, int idxSize) {
		this.idxStart = idxStart;
		this.idxSize = idxSize;
		totalSize = 0;
		comseqDao = new ArrayList<>();
		cominDao = new ArrayList<>();
		comoutDao = new ArrayList<>();
	}

	public void updateDB() throws Exception {
		getDB();
		requestAPI3();
		parsingApiData();
		setCominDB();
		setComoutDB();
		showResult();
	}

	public void getDB() {

		try {
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;

			String sql = "SELECT * FROM Comseq WHERE com_id BETWEEN ? AND ?";

			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hcdb", "hcdb");
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, idxStart);
			pstmt.setInt(2, idxStart + idxSize);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				int id = rs.getInt(1);
				int year = rs.getInt(2);
				int[] seq = new int[12];
				for (int i = 0; i < 12; i++)
					seq[i] = rs.getInt(i + 3);
				comseqDao.add(new ComseqDAO(id, year, seq));
			}

			pstmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void requestAPI3() throws Exception {

		response = new String[comseqDao.size() * 12];

		for (int i = 0; i < comseqDao.size(); i++) {
			for (int j = 0; j < 12; j++) {
				if (comseqDao.get(i).seq[j] == 0)
					continue;
				String year = Integer.toString(comseqDao.get(i).seq_year);
				String month = "";
				if ((j + 1) >= 10)
					month = Integer.toString(j + 1);
				else
					month = "0" + Integer.toString(j + 1);

				StringBuilder urlBuilder = new StringBuilder(
						"http://apis.data.go.kr/B552015/NpsBplcInfoInqireService/getPdAcctoSttusInfoSearch");
				urlBuilder.append("?" + URLEncoder.encode("ServiceKey", "UTF-8")
						+ "=fntF2875bK1vH0uhenZ5rExmG8r8MCuStfZBb2ePzS1yl2vRH5cIsS5eF67XC%2F4A1CD3KGrvnp4bG2SicB9fcA%3D%3D");
				urlBuilder.append("&" + URLEncoder.encode("seq", "UTF-8") + "="
						+ URLEncoder.encode(Integer.toString(comseqDao.get(i).seq[j]), "UTF-8"));
				urlBuilder.append("&" + URLEncoder.encode("data_crt_ym", "UTF-8") + "="
						+ URLEncoder.encode(year + month, "UTF-8"));

				URL url = new URL(urlBuilder.toString());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Content-type", "application/json");
				System.out.println("Response code: " + conn.getResponseCode());
				BufferedReader rd;
				if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
					rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				} else {
					rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				}
				String line;

				while ((line = rd.readLine()) != null) {
					if (line.length() < 100)
						continue;
					response[totalSize++] = line + "id" + Integer.toString(comseqDao.get(i).com_id) + "<" + "year"
							+ year + "<" + "month" + month + "<";
				}
				rd.close();
				conn.disconnect();
				
				Thread.sleep(100);
			}
		}
	}

	public void parsingApiData() {

		ArrayList<YIMS> yims = new ArrayList<>();

		for (int i = 0; i < totalSize; i++) {

			// System.out.println(response[i]);

			String tmp = "";
			int idx;
			int id;
			int year;
			int month;
			int lssJnngpCnt;
			int nwAcqzrCnt;

			idx = response[i].indexOf("id") + 2;
			tmp = "";
			while (true) {
				if (response[i].charAt(idx) == '<')
					break;
				tmp += response[i].charAt(idx++);
			}
			id = Integer.parseInt(tmp);

			idx = response[i].indexOf("year") + 4;
			tmp = "";
			while (true) {
				if (response[i].charAt(idx) == '<')
					break;
				tmp += response[i].charAt(idx++);
			}
			year = Integer.parseInt(tmp);

			idx = response[i].indexOf("month") + 5;
			tmp = "";
			while (true) {
				if (response[i].charAt(idx) == '<')
					break;
				tmp += response[i].charAt(idx++);
			}
			month = Integer.parseInt(tmp);

			idx = response[i].indexOf("lssJnngpCnt") + 12;
			tmp = "";
			while (true) {
				if (response[i].charAt(idx) == '<')
					break;
				tmp += response[i].charAt(idx++);
			}
			lssJnngpCnt = Integer.parseInt(tmp);

			idx = response[i].indexOf("nwAcqzrCnt") + 11;
			tmp = "";
			while (true) {
				if (response[i].charAt(idx) == '<')
					break;
				tmp += response[i].charAt(idx++);
			}
			nwAcqzrCnt = Integer.parseInt(tmp);

			yims.add(new YIMS(id, year, month, nwAcqzrCnt, lssJnngpCnt));
		}

		ArrayList<YIMS> yimslist = new ArrayList<>();

		for (int i = 0; i < yims.size(); i++) {
			boolean flag = false;
			for (int j = 0; j < yimslist.size(); j++) {
				if (yims.get(i).id == yimslist.get(j).id && yims.get(i).year == yimslist.get(j).year) {
					yimslist.get(j).inArr[yims.get(i).month - 1] = yims.get(i).in;
					yimslist.get(j).outArr[yims.get(i).month - 1] = yims.get(i).out;
					flag = true;
				}
			}
			if (flag == false) {
				int[] inArr = new int[12];
				int[] outArr = new int[12];
				for (int j = 0; j < 12; j++) {
					if (yims.get(i).month == j + 1) {
						inArr[j] = yims.get(i).in;
						outArr[j] = yims.get(i).out;
					}
				}
				yimslist.add(new YIMS(yims.get(i).id, yims.get(i).year, inArr, outArr));
			}
		}

		for (int i = 0; i < yimslist.size(); i++) {
			int id = yimslist.get(i).id;
			int year = yimslist.get(i).year;
			int[] in = yimslist.get(i).inArr;
			int[] out = yimslist.get(i).outArr;

			cominDao.add(new CominDAO(id, year, in));
			comoutDao.add(new ComoutDAO(id, year, out));
		}

		// for(int i=0;i<yimslist.size();i++) {
		// System.out.print("[new ID?"+yimslist.get(i).id+"]");
		// System.out.print("[YEAR?"+yimslist.get(i).year+"] ");
		// for(int j=0;j<12;j++)
		// System.out.print(yimslist.get(i).inArr[j] + " ");
		// System.out.println();
		// System.out.print("[fire ID?"+yimslist.get(i).id+"]");
		// System.out.print("[YEAR?"+yimslist.get(i).year+"] ");
		// for(int j=0;j<12;j++)
		// System.out.print(yimslist.get(i).outArr[j] + " ");
		// System.out.println();
		// }
	}

	public void setCominDB() {

		try {
			Connection conn = null;
			PreparedStatement pstmt = null;

			String sql = "INSERT INTO Comin VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hcdb", "hcdb");
			pstmt = conn.prepareStatement(sql);

			for (int i = 0; i < cominDao.size(); i++) {
				pstmt.setInt(1, cominDao.get(i).com_id);
				pstmt.setInt(2, cominDao.get(i).in_year);
				for (int j = 0; j < 12; j++)
					pstmt.setInt(j + 3, cominDao.get(i).in[j]);

				pstmt.executeUpdate();
			}
			pstmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setComoutDB() {

		try {
			Connection conn = null;
			PreparedStatement pstmt = null;

			String sql = "INSERT INTO Comout VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hcdb", "hcdb");
			pstmt = conn.prepareStatement(sql);

			for (int i = 0; i < comoutDao.size(); i++) {
				pstmt.setInt(1, comoutDao.get(i).com_id);
				pstmt.setInt(2, comoutDao.get(i).out_year);
				for (int j = 0; j < 12; j++)
					pstmt.setInt(j + 3, comoutDao.get(i).out[j]);

				pstmt.executeUpdate();
			}
			pstmt.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void showResult() {

		System.out.println("#####[COMIN DAO]#####");
		for (int i = 0; i < cominDao.size(); i++) {
			System.out.print("[ID>" + cominDao.get(i).com_id + "]");
			System.out.print("[YEAR>" + cominDao.get(i).in_year + "] ");
			for (int j = 0; j < 12; j++)
				System.out.print(cominDao.get(i).in[j] + " ");
			System.out.println();
		}
		System.out.println("E");
		System.out.println("N");
		System.out.println("D");

		System.out.println("#####[COMOUT DAO]#####");
		for (int i = 0; i < comoutDao.size(); i++) {
			System.out.print("[ID>" + comoutDao.get(i).com_id + "]");
			System.out.print("[YEAR>" + comoutDao.get(i).out_year + "] ");
			for (int j = 0; j < 12; j++)
				System.out.print(comoutDao.get(i).out[j] + " ");
			System.out.println();
		}
	}
}

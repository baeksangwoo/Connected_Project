package com.example.student.kreditjjob;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CursorAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Toolbar myToolbar;

    // Declare Variables
    ListView list;
    ListView history;
    LinearLayout historyLayout;
    ListViewAdapter adapter;
    android.support.v7.widget.SearchView searchView;
    String[] companyList;
    ArrayList<Company> arrayList = new ArrayList<Company>();

    public static String dirPath = Environment.getExternalStorageDirectory().getAbsoluteFile() + "/Android/com.four.hiddenchampion/temp";
    public static String fileName = "history.txt";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //loading Activity불러오기
        Intent intent = new Intent(MainActivity.this, LoadingActivity.class);
        startActivity(intent);

        //toolbar
        myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setIcon(R.drawable.icon_main5);
        getSupportActionBar().setTitle("Hidden Champion");

        File file = new File(dirPath);
        if (!file.exists())
            file.mkdirs();
        historyLayout = (LinearLayout) findViewById(R.id.historyLayout);

        /*ArrayList<String> historyList = readTextFile();
        ArrayAdapter hisAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, historyList);
        history = (ListView) findViewById(R.id.historyView);
        history.setAdapter(hisAdapter);*/
/*        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.);
        getSupportActionBar().setTitle("");*/

        // Generate sample data
        arrayList = readRawTextFile();

        /*companyList = new String[]{"삼성", "엘지", "네이버", "카카오", "구글", "오라클", "(주)비즈스프링", "티맥스", "아이오시스"};*/

        // Locate the ListView in listview_main.xml
        list = (ListView) findViewById(R.id.listView);

        /*for (int i = 0; i < companyList.length; i++) {
            Company company = new Company(companyList[i]);
            // Binds all strings into an array
            arrayList.add(company);
        }*/

        // Pass results to ListViewAdapter Class
        adapter = new ListViewAdapter(this, arrayList);

        // Binds the Adapter to the ListView
        list.setAdapter(adapter);

        // Locate the EditText in listview_main.xml
        //editsearch = (SearchView) findViewById(R.id.search);
        // editsearch.setOnQueryTextListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        final ArrayList<String> historyList = readTextFile();
        final ArrayAdapter hisAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, historyList);
        history = (ListView) findViewById(R.id.historyView);
        history.setAdapter(hisAdapter);

        history.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(final AdapterView<?> parent, View view,
                                           final int position, long id) {
                AlertDialog diaBox=new AlertDialog.Builder(MainActivity.this)
                        .setTitle("열람 기록 삭제")
                        .setMessage("해당 기록을 삭제하시겠습니까?")
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                               historyList.remove(position);
                                writeTextFile(historyList);

                                history.clearChoices();
                                history.setAdapter(hisAdapter);
                                adapter.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("NO", null)
                        .create();
                diaBox.show();
                return true;
            }
        });

        history.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // item 이름 가져오기
                String company = (String) parent.getItemAtPosition(position);

                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                intent.putExtra("company", company);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        searchView = (android.support.v7.widget.SearchView) searchItem.getActionView();
        searchView.setQueryHint("기업명을 입력하세요.");
        searchView.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {

                                              @Override
                                              public boolean onQueryTextSubmit(String query) {

                                                  return false;
                                              }

                                              @Override
                                              public boolean onQueryTextChange(String newText) {
                                                  if(newText.equals("")){
                                                      historyLayout.setVisibility(View.VISIBLE);
                                                  }
                                                  else {
                                                      historyLayout.setVisibility(View.INVISIBLE);
                                                  }
                                                  String text = newText;
                                                  adapter.filter(text);
                                                  return false;
                                              }
                                          }
        );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        return super.onOptionsItemSelected(item);

    }

    public ArrayList<String> readTextFile() {
        ArrayList<String> historyList = new ArrayList<>();
        ArrayList<String> resultList = new ArrayList<>();
        try {
            InputStream is = new FileInputStream(dirPath + "/" + fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = "";
            while ((line = br.readLine()) != null) {
                historyList.add(line);
            }

            if (!historyList.isEmpty()) {

                String recentStr = historyList.get(historyList.size() - 1);
                resultList.add(recentStr);
                int cnt = 0;
                int len = historyList.size() - 1;
                for (int i = len-1; i >= 0; i--) {
                    if (historyList.get(i).equals(recentStr)) {
                        historyList.remove(i);
                    } else {
                        resultList.add(historyList.get(i));
                        cnt++;
                    }
                    if (cnt == 10) break;
                }
            }

        } catch (Exception e) {
            Log.i("readTextFile", e.toString());
        }
        writeTextFile(resultList);
        return resultList;
    }

    public ArrayList<Company> readRawTextFile() {
        ArrayList<Company> resultList = new ArrayList<>();
        StringBuffer stringBuffer = new StringBuffer();
        try {
            InputStream is = getResources().openRawResource(R.raw.company_name);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String line = "";
            while ((line = br.readLine()) != null) {
                resultList.add(new Company(line));
            }

        } catch (Exception e) {
            Log.i("readTextFile", e.toString());
        }

        return resultList;
    }

    public void writeTextFile(ArrayList<String> resultList) {
        try {
            FileWriter fw = new FileWriter(dirPath +"/"+fileName);
            for(int i=0;i<resultList.size();i++)
                fw.write(resultList.get(i)+"\n");
            fw.close();
        } catch (Exception e) {
            Log.v("writeTextFile ERROR", e.toString());
        }
    }

/*    public void showList(View view){
        if(list.getVisibility() == View.VISIBLE)
            list.setVisibility(View.INVISIBLE);
        else
            list.setVisibility(View.VISIBLE);
    }*/
}


